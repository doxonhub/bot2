Thank you for your purchase! If you need help or have a question feel free to join Support Server - https://discord.gg/APnKTdbM4w
All Informations on how to setup the bot can be found on Official Wiki - https://champion-bot.gitbook.io/tickets/

** You're not allowed to redistribute or leak this product **